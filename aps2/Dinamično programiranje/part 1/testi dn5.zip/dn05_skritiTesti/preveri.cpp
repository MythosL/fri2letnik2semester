
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <fstream>

using namespace std;
using ii = pair<int, int>;

template<typename F, typename S> ostream& operator<<(ostream& os, const pair<F, S>& par) {
    return os << par.first << "/" << par.second;
}

template<typename T> ostream& operator<<(ostream& os, const vector<T>& v) {
    bool prvic = true;
    os << "[";
    for (const T& e: v) {
        if (!prvic) os << ", ";
        prvic = false;
        os << e;
    }
    return os << "]";
}

int main(int argc, char** argv) {
    if (argc != 4) {
        cerr << "./preveri testNN.in testNN.out testNN.res" << endl;
        return 1;
    }

    ifstream vhod(argv[1]);
    if (!vhod.is_open()) {
        cerr << "Datoteka " << argv[1] << " ne obstaja." << endl;
        return 1;
    }

    int stMest, stPostaj;
    vhod >> stMest >> stPostaj;

    vector<int> prebivalstvo(stMest);
    for (int i = 0; i < stMest; i++) {
        vhod >> prebivalstvo[i];
    }
    vhod.close();

    ifstream referencna(argv[2]);
    if (!referencna.is_open()) {
        cerr << "Datoteka " << argv[2] << " ne obstaja." << endl;
        return 1;
    }

    int praviRezultat;
    referencna >> praviRezultat;
    referencna.close();

    ifstream dejanska(argv[3]);
    if (!dejanska.is_open()) {
        cerr << "Datoteka " << argv[3] << " ne obstaja." << endl;
        return 1;
    }

    int dobljeniRezultat;
    dejanska >> dobljeniRezultat;
    vector<int> postaje;

    int postaja;
    while (dejanska >> postaja) {
        postaje.push_back(postaja);
    }

    dejanska.close();

    if (praviRezultat != dobljeniRezultat) {
        cout << 0 << endl;
        return 0;
    }

    if (postaje.size() != stPostaj) {
        cout << 1 << endl;
        return 0;
    }

    for (int i = 1; i < stPostaj; i++) {
        if (postaje[i] <= postaje[i - 1]) {
            cout << 1 << endl;
            return 0;
        }
    }

    int ocena = 0;
    for (int i = 0; i < stMest; i++) {
        int p = lower_bound(postaje.begin(), postaje.end(), i) - postaje.begin();
        int p1 = postaje.at(p == 0 ? p : p - 1);
        int p2 = postaje.at(p == stPostaj ? p - 1 : p);
        int d = min(abs(i - p1), abs(i - p2));
        ocena += prebivalstvo[i] * d;
    }
    cout << (ocena == dobljeniRezultat ? 2 : 1) << endl;

    return 0;
}
