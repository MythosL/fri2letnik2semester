
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <iomanip>

using namespace std;
using ii = pair<int, int>;

template<typename F, typename S> ostream& operator<<(ostream& os, const pair<F, S>& par) {
    return os << par.first << "/" << par.second;
}

template<typename T> ostream& operator<<(ostream& os, const vector<T>& v) {
    bool prvic = true;
    os << "[";
    for (const T& e: v) {
        if (!prvic) os << ", ";
        prvic = false;
        os << e;
    }
    return os << "]";
}

int simuliraj(const string& ukazi) {
    int kurzor = 0;
    int odlozisce = 0;
    int n = 1;

    for (char ukaz: ukazi) {
        switch (ukaz) {
            case 'h':
                kurzor = max(kurzor - 1, 0);
                break;

            case 'l':
                kurzor = min(kurzor + 1, n - 1);
                break;

            case 'Y':
                odlozisce = n - kurzor;
                break;

            case 'P':
                n += odlozisce;
                kurzor += odlozisce - 1;
                break;

            default:
                return 0;
        }
    }
    return n;
}

int main(int argc, char** argv) {
    if (argc != 4) {
        cerr << "./preveri testNN.in testNN.out testNN.res" << endl;
        return 1;
    }

    ifstream vhod(argv[1]);
    if (!vhod.is_open()) {
        cerr << "Datoteka " << argv[1] << " ne obstaja." << endl;
        return 1;
    }

    int ciljnaDolzina;
    vhod >> ciljnaDolzina;
    vhod.close();

    ifstream referencna(argv[2]);
    if (!referencna.is_open()) {
        cerr << "Datoteka " << argv[2] << " ne obstaja." << endl;
        return 1;
    }

    string praviUkazi;
    referencna >> praviUkazi;
    referencna.close();

    ifstream dejanska(argv[3]);
    if (!dejanska.is_open()) {
        cerr << "Datoteka " << argv[3] << " ne obstaja." << endl;
        return 1;
    }

    string dobljeniUkazi;
    dejanska >> dobljeniUkazi;
    dejanska.close();

    if (praviUkazi == dobljeniUkazi) {
        cout << 1 << endl;
        return 0;
    }

    int dobljenaDolzina = simuliraj(dobljeniUkazi);
    if (dobljenaDolzina == ciljnaDolzina) {
        int ref = praviUkazi.size();
        int dob = dobljeniUkazi.size();
        if (dob <= ref) {
            cout << 1 << endl;
            return 0;
        }
        double tocke = max(0.0, double(2 * ref - dob + 1) / double(2 * ref));
        cout << fixed << tocke << endl;
    } else {
        cout << 0 << endl;
    }

    return 0;
}
