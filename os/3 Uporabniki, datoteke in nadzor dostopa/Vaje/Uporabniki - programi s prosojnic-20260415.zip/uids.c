#include <stdio.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
	printf("UID: %d\n", getuid());
	printf("EUID: %d\n", geteuid());

	printf("GID: %d\n", getgid());
	printf("EGID: %d\n", getegid());
}
