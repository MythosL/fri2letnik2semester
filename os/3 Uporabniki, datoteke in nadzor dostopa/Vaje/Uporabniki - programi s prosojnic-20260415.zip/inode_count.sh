#!/bin/bash
mkdir -p 1 2 3

ls -dil "$PWD" . */..
