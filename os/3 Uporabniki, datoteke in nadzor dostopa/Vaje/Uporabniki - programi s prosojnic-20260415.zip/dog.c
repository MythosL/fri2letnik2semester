#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char** argv) {
	int fd = open(argv[1], O_RDONLY);
	char buf[4096];
	int cnt, count = 0;
	while ( (cnt = read(fd, buf, 4096)) > 0 ) {
		write(1, buf, cnt);
		count += cnt;
	}
	close(fd);
	printf("Št. kopiranih bajtov: %d\n", count);
}
