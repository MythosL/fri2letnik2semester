#include <dirent.h>
#include <unistd.h>

int main(int argc, char** argv) {
	DIR* dir = opendir(argv[1]);
	struct dirent * entry;
	while ( (entry = readdir(dir)) != 0) {
		write(1, entry->d_name, entry->d_namlen);
		write(1, "\n", 1);
	}
	closedir(dir);
}

