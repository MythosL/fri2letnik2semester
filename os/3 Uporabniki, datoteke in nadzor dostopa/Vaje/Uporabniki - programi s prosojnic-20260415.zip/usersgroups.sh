#!/bin/bash

uids=$(cat /etc/passwd | egrep -v \# | cut -d: -f3 | sort -g)
echo $uids
for uid in $uids; do
	(( uid < 1000 )) && continue
	line=$(cat /etc/passwd | egrep ":x:$uid:")
	name=$(echo $line | cut -d: -f1)
	gid=$(echo $line | cut -d: -f4)
	groups=$(cat /etc/group | egrep ":x:$gid:" | cut -d: -f1)
	secondary=$(cat /etc/group | egrep ".$name" | cut -d: -f1)
	echo Uid: $uid, name: $name, gid: $gid, groups: $groups $secondary
done
