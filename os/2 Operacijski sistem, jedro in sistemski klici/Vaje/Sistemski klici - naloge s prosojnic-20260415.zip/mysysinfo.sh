#!/bin/bash

echo Ime računalnika: $(cat /etc/hostname)
echo

echo 'Operacijski sistem: '
cat /proc/version
echo

echo Št. jedr procesorja: $(egrep processor /proc/cpuinfo | wc -l)
echo

echo Velikost pomnilnika: $(egrep MemTotal /proc/meminfo | cut -d: -f2)
echo

echo Št. procesov $(echo /proc/[0-9]* | wc -w)
echo
