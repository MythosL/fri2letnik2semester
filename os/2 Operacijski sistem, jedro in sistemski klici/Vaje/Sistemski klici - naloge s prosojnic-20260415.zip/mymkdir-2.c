#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>

#define MAXLEN 256

int main(int argc, char* argv[]) {
    // pid in ppid procesa
    printf("Pid procesa: %d\n", getpid());
    printf("PPid procesa: %d\n", getppid());

    // trenutni delovni imenik procesa
    char cwd[MAXLEN];
    getcwd(cwd, MAXLEN);
    printf("Trenutni imenik procesa: '%s'\n", cwd);

    // ustvarjanje imenika
    char* dir = argv[1];
    if (mkdir(dir, 0777) < 0) {
        int koda = errno;
        perror(argv[0]);
        exit(koda);
    }
    printf("Imenik '%s' uspešno ustvarjen.\n", dir);

    // skok v imenik
    if (chdir(dir) < 0) {
        int koda = errno;
        perror(argv[0]);
        exit(koda);
    }

    getcwd(cwd, MAXLEN);
    printf("Trenutni imenik procesa: '%s'\n", cwd);

    exit(0);
}
