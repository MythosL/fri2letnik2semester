#include <stdio.h>

int main(int argc, char* argv[], char* environ[]) {
    // Izpis imena programa
    printf("Ime programa: '%s'\n", argv[0]);

    // Izpis argumentov
    int i;
    for (i = 1; i < argc; i++)
        printf("%s\n", argv[i]);

    // Izpis okoljskih spremenljivk
    i = 0;
    while (environ[i])
       printf("%s\n", environ[i++]);
}
