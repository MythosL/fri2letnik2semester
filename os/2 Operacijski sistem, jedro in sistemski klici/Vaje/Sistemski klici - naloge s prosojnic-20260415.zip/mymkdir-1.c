#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>

#define MAXLEN 256

int main(int argc, char* argv[]) {
    // pid in ppid procesa
    printf("Pid procesa: %d\n", getpid());
    printf("PPid procesa: %d\n", getppid());

    // trenutni delovni imenik procesa
    char cwd[MAXLEN];
    getcwd(cwd, MAXLEN);
    printf("Trenutni imenik procesa: '%s'\n", cwd);

    // ustvarjanje imenika
    char* dir = argv[1];
    if (mkdir(dir, 0777) < 0) {
        fprintf(stderr, "Imenik '%s' ni uspešno ustvarjen.\n", dir);
        exit(1);
    }
    printf("Imenik '%s' uspešno ustvarjen.\n", dir);

    // skok v imenik
    chdir(dir);

    getcwd(cwd, MAXLEN);
    printf("Trenutni imenik procesa: '%s'\n", cwd);

    exit(0);
}
